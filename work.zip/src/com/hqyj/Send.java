package com.hqyj;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.util.Scanner;

public class Send {

	public static void main(String[] args) throws Exception {
		//接收消息
		new Thread(()->{
			try {
				//监听消息的端口
				DatagramSocket ds = new DatagramSocket(9090);
				while (true) {
					byte[] buf = new byte[1024];
					DatagramPacket dp = new DatagramPacket(buf, buf.length);
					ds.receive(dp);
					System.out.println(new String(dp.getData(), 0, dp.getLength()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}).start();
		//发送消息
		Scanner input = new Scanner(System.in);
		System.out.println("输入姓名：");
		String name = input.next();
		DatagramSocket ds = new DatagramSocket();
		//对方IP
		InetAddress ip = InetAddress.getByName("localhost");
		
		while (true) {
			System.out.println("输入发送的内容：");
			byte[] buf = (name+":"+input.next()).getBytes();
			//向对方IP和端口发送数据报(包)
			DatagramPacket dp = new DatagramPacket(buf, buf.length, ip, 8080);
			ds.send(dp);
		}
	}

}
