package com.hqyj.service.impl;

import com.hqyj.pojo.Ctrlrecord;
import com.hqyj.mapper.CtrlrecordMapper;
import com.hqyj.service.CtrlrecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jojo
 * @since 2024-09-03
 */
@Service
public class CtrlrecordServiceImpl extends ServiceImpl<CtrlrecordMapper, Ctrlrecord> implements CtrlrecordService {

}
