package com.hqyj.controller;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqyj.pojo.Ctrlrecord;
import com.hqyj.pojo.Users;
import com.hqyj.service.CtrlrecordService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jojo
 * @since 2024-09-03
 */
@RestController
@RequestMapping("/ctrlrecord")
public class CtrlrecordController {
	@Autowired
	private CtrlrecordService cs;
	
	@RequestMapping("/insert")
	public  String insert(@RequestBody Ctrlrecord c)
    {
    	cs.save(c);
    	return "1";
    }
	 @RequestMapping("/update")
	 public  String update(@RequestBody Ctrlrecord c)
	 {
	    cs.updateById(c);
	    return "1";
	 }
	 @RequestMapping("/delete")
	 public  String delete(Integer rid)
	 {
		 //System.out.println(rid);
	    cs.removeById(rid);
	    return "1";
	 }
	 @RequestMapping("/deleteList")
	 public  String deleteList(@RequestBody ArrayList<Integer> ids)
	 {
		 
	    cs.removeByIds(ids);
	    return "1";
	 }
	 @RequestMapping("/selectByPage")
	 public Page selectByPage(int page,int line)
	 {
	    return cs.page(new Page(page,line));
	 }
}

