package com.hqyj.controller;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.websocket.OnClose;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.hqyj.pojo.Ctrlrecord;
import com.hqyj.pojo.Device;
import com.hqyj.service.CtrlrecordService;
import com.hqyj.service.DeviceService;

@ServerEndpoint("/devicectrl/{did}")
public class SocketUtil {
    private Session session;
    private DatagramSocket ds;    
    @OnOpen
    public void connect(Session session, @PathParam("did") int did) {
        this.session = session;
        new Thread(()->{
            try {
                acceptData(did);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }).start();
    }    
    /**
     * 接收stm32板信息
     * @param did 
     * @throws Exception
     */
    public void acceptData(int did) throws Exception {
        System.out.println("---开始准备接收stm32信息---");
        WebApplicationContext beans = ContextLoader.getCurrentWebApplicationContext();
        DeviceService deviceService = (DeviceService) beans.getBean("deviceServiceImpl");
        CtrlrecordService ctrlrecordService = (CtrlrecordService) beans.getBean("ctrlrecordServiceImpl");
        Device device = deviceService.getById(did);
        boolean save = true;
        //套接字用来收发数据
        ds = new DatagramSocket(device.getListenport());
        byte[] buf = new byte[1024];
        //数据报文
        DatagramPacket dp = new DatagramPacket(buf, buf.length);
        int cnt=0;
        while(true)
        {
        ds.receive(dp);//通过套接字对象ds接收数据存储在dp对象中
        String res = new String(dp.getData(),0,dp.getLength());
        System.out.println("内容是："+res);
        cnt++;
        if(cnt<10)
        {
        	continue;
        }
        else
        {
        	cnt=0;
        }
        session.getAsyncRemote().sendText(res);
        Ctrlrecord record = new Ctrlrecord(null, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), "温湿度", "输出", res, did, null);
        ctrlrecordService.save(record);
        }
    }        
    @OnClose
    public void closed() {
        this.session = null;
        System.out.println("----------close-------------");
        ds.close();
    }    
    /**
     * 给stm32板发送指令
     * @param info
     * @throws Exception
     */
    public static void sendData(String ip, Integer port, String info) throws Exception{
        DatagramSocket ds = new DatagramSocket();
        byte[] buf = info.getBytes();
        //发送给对方的内容，携带目标ip地址，目标端口号
        DatagramPacket dp = new DatagramPacket(
                buf,            //参数1：发送给对方的内容
                buf.length,    //参数2：发送给对方内容的长度
                InetAddress.getByName(ip),//参数3：对方的ip地址
                port);        //参数4：对方监听的端口号                
        ds.send(dp);
        ds.close();
    }
}
