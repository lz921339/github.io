package com.hqyj.controller;


import java.io.Console;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqyj.pojo.Users;
import com.hqyj.service.UsersService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jojo
 * @since 2024-09-03
 */
@RestController
@RequestMapping("/users")
public class UsersController {
	@Autowired
    private UsersService us;  // 假设有一个服务类用于处理用户相关操作

    @PostMapping("/selectLogin")
    @ResponseBody
    public String selectLogin(@RequestParam String usid, @RequestParam String upwd) {
        Users u=us.getById(usid);
        if(u!=null &&u.getUpwd().equals(upwd))
        {
        	return "1";
        	
        }
        return "";
        
    }
    @RequestMapping("/insert")
    public  String insert(@RequestBody Users u)
    {
    	us.save(u);
    	return "1";
    }
    @RequestMapping("/update")
    public  String update(@RequestBody Users u)
    {
    	us.updateById(u);
    	return "1";
    }
    @RequestMapping("/delete")
    public  String delete(String usid)
    {
    	us.removeById(usid);
    	return "1";
    }
    @RequestMapping("/deleteList")
    public  String deleteList(@RequestBody ArrayList<String> ids)
    {
    	us.removeByIds(ids);
    	return "1";
    }
    @RequestMapping("/selectByPage")
    public Page selectByPage(int page ,int line)
    {
    	return us.page(new Page(page,line));
    }
}

