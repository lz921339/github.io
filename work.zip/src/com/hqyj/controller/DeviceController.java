package com.hqyj.controller;



import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqyj.mapper.DeviceMapper;
import com.hqyj.pojo.Ctrlrecord;
import com.hqyj.pojo.Device;
import com.hqyj.service.CtrlrecordService;
import com.hqyj.service.DeviceService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jojo
 * @since 2024-09-03
 */
@RestController
@RequestMapping("/device")
public class DeviceController {
	@Autowired
	private DeviceService ds;
	@Autowired
	CtrlrecordService cs;	
	@RequestMapping("/insert")
	public  String insert(@RequestBody Device c)
    {
    	ds.save(c);
    	return "1";
    }
	 @RequestMapping("/update")
	 public  String update(@RequestBody Device c)
	 {
	    ds.updateById(c);
	    return "1";
	 }
	 @RequestMapping("/delete")
	 public  String delete(Integer did)
	 {
	    ds.removeById(did);
	    //System.out.println(did);
	    return "1";
	 }
	 @RequestMapping("/deleteList")
	 public  String deleteList(@RequestBody ArrayList<Integer> ids)
	 
	 
	 {
	    ds.removeByIds(ids);
	    return "1";
	 }
	 @RequestMapping("/selectByPage")
	 public Page selectByPage(int page,int line)
	 {
	    return ds.page(new Page(page,line));
	 }
	 @Autowired
	 private DeviceMapper deviceMapper;
	 
	 @RequestMapping("/selectByProperty")
	 public List<Device> selectByProperty(String propertyName, String value) {
		    QueryWrapper qw = new QueryWrapper();

		    qw.ne(propertyName, value);
		    return deviceMapper.selectList(qw);
		}
		@RequestMapping("/selectOne")
		public Device selectOne(Integer did) {
			return ds.getById(did);
		}
		@RequestMapping("updateSwitch")
		public String updateSwitch(String info, @RequestBody Device u) throws Exception {
			//实现指令操控
			SocketUtil.sendData(u.getDip(), u.getDport(), info);
			ds.updateById(u);
			//保存发送指令记录
			String rtime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
			Ctrlrecord record = new Ctrlrecord(null, rtime, "开关", "输入", u.getDstate(), u.getDid(), null);
			cs.save(record);
			return "1";
		}
}

