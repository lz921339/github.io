package com.hqyj.mapper;

import com.hqyj.pojo.Device;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jojo
 * @since 2024-09-03
 */
public interface DeviceMapper extends BaseMapper<Device> {

}
