package com.hqyj;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.gq.util.CodeConfig;

public class CreateCode {
    public static void main(String[] args) {
        AutoGenerator mpg = new AutoGenerator();
        //先设置包名和数据库信息
        String parent = "com";
        String module = "hqyj";
        String[] dbinfo = {
    		//"com.mysql.jdbc.Driver",
    		//"jdbc:mysql://localhost:3306/smarthome?useUnicode=true&amp;characterEncoding=utf-8",
    		//mysql8.0用下面两行
    		"com.mysql.cj.jdbc.Driver",
    		"jdbc:mysql://localhost:3306/smarthome?useSSL=false&useUnicode=true&characterEncoding=UTF8&serverTimezone=GMT",
    		"root",
    		"921339"};
        
        //全局配置
        GlobalConfig gc = new GlobalConfig();
        gc.setAuthor("jojo");//类创建者
        gc.setOutputDir(System.getProperty("user.dir")+"/src");
        gc.setOpen(false);//是否打开资源管理器(文件夹浏览窗口)
        gc.setFileOverride(true);
        //gc.setMapperName("%sDao");//设置Dao名，默认名为Mapper
        //gc.setXmlName("%sDao");//设置MapperXml名，默认名为Mapper
        gc.setServiceName("%sService");//去掉默认的'I'
        gc.setIdType(IdType.ASSIGN_ID);//设置主键类型，自增会自动调整
        gc.setDateType(DateType.ONLY_DATE);//设置日期类型
        mpg.setGlobalConfig(gc);

        //数据源配置
        DataSourceConfig ds = new DataSourceConfig();
        ds.setDriverName(dbinfo[0]);
        ds.setUrl(dbinfo[1]);
        ds.setUsername(dbinfo[2]);
        ds.setPassword(dbinfo[3]);
        ds.setDbType(DbType.MYSQL);
        mpg.setDataSource(ds);
        //包名配置
        PackageConfig pc = new PackageConfig();
        pc.setParent(parent);
        pc.setModuleName(module);
        pc.setEntity("pojo");//默认为entity
        //pc.setMapper("dao");//默认为mapper
        pc.setXml("mapper");//默认为mapper/xml
        mpg.setPackageInfo(pc);

        //策略配置
        StrategyConfig sc = new StrategyConfig();
        //sc.setInclude("users");//默认生成所有表
        sc.setNaming(NamingStrategy.underline_to_camel);//类名下划线改驼峰命名
        sc.setColumnNaming(NamingStrategy.underline_to_camel);//属性名下划线改驼峰命名
        sc.setEntityLombokModel(true);//设置lombok注解
        sc.setRestControllerStyle(true);
        sc.setControllerMappingHyphenStyle(true);//支持路径符号连接
        //sc.setEntityTableFieldAnnotationEnable(true);//设置表及字段注解
        mpg.setStrategy(sc);

        mpg.execute();
        //添加项目配置文件
        //mysql8.0打开下面注释
        dbinfo[1] = "jdbc:mysql://localhost:3306/smarthome?useSSL=false&amp;useUnicode=true&amp;characterEncoding=UTF8&amp;serverTimezone=GMT";
        CodeConfig.createConfig(parent, module, dbinfo);
        System.out.println("-----------项目搭建完毕-------------");
    }
}
