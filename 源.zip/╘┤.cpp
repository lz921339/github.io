#define _CRT_NONSTDC_NO_DEPRECATE
#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>

using namespace std;
int main()
{
	int n;
	int n1;
	cin >> n >> n1;
	srand((unsigned)time(NULL));
	for (int i=0;i<n;i+=1)
	{
		int a;
		double c;
		string s;
		int lastsign = 1;//0Ϊ+-��1Ϊ*/
		for (int j=0;j<n1;j+=1)
		{
			a = 1+rand() % 10;
			if (j>0)
			{
				
				int signal = rand() % 4;
				int signal2 = rand() % 2;
				if (signal == 0)
				{
					
					
					char str[20];
					itoa(a, str, 10);
					if (signal2==0)
					{
						s = s + "+"+str;
					}
					else
					{
						s = "+" + s;
						s = str+s;
					}
					c = c + a;
					lastsign = 0;
				}
				else if (signal == 1)
				{
					
					char str[20];
					itoa(a, str, 10);
					if (signal2 == 0)
					{
						c = c- a;
						s = s + "-" + str;
					}
					else
					{
						c = a - c;
						s = "-" + s;
						s = str + s;
					}
					lastsign = 0;
				}
				else if (signal == 2)
				{
					
					char str[20];
					itoa(a, str, 10);
					if (lastsign == 0)
					{
						s = "(" + s + ")";
					}
					if (signal2 == 0)
					{
						s = s +"*"+ str;
					}
					else
					{
						s = "*" + s;
						s = str + s;
					}
					c = c * a;
					lastsign = 1;
				}
				else if (signal == 3)
				{
					char str[20];
					itoa(a, str, 10);
					if (lastsign == 0)
					{
						s = "(" + s + ")";
					}
					if (signal2 == 0)
					{
						s = s + "/" + str;
					}
					else
					{
						s = "/" + s;
						s = str + s;
					}
					if (signal2==0)
					{
						c = c / a;
					}
					else
					{
						c = a/c;
					}
					lastsign = 1;
				}
				

			}
			else
			{
				c = a;
				char str[20];
				itoa(a, str, 10);
				s = s + str;
			}

		}
		cout << s;
		cout << "=" << c << endl;

	}
}